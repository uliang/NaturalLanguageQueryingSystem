"""
Implementation of a state monad. 

Author: Tang U-Liang 

----------------------------------

"""
import typing as typ
from functools import reduce
from operator import or_, itemgetter
from abc import ABC, abstractmethod
from contextlib import suppress
import inspect 

import attr 

S, T, U = typ.TypeVar('S'), typ.TypeVar('T'), typ.TypeVar('U')


class StateLike(typ.Protocol[S, T]) :
    def __call__(self, arg:S) -> typ.Tuple[T, S] :
        pass

class Bindable(typ.Protocol[T, S, U]) : 
    def __call__(self, res_: T) -> StateLike[S, U] : 
        pass 


class MonadBase(ABC) : 

    @abstractmethod
    def bind(self, f) : 
        pass 

    def __or__(self, f) : 
        return self.bind(f)

    def pipe(self, *steps) : 
        return reduce(or_, steps, self)


@attr.s
class State(MonadBase): 
    
    state:StateLike = attr.ib()
        
    @classmethod
    def unit(cls, x:T) -> StateLike[S, T] :
        return cls(lambda s_: (x, s_))

    def __call__(self, s_:S) -> typ.Tuple[T, S] : 
        return self.state(s_)

    def bind(self, f: Bindable[T, S, U]) -> StateLike[S, U] : 
        def composition(s_:S) -> typ.Tuple[U, S] :
            ret_t_, new_s_ = self.state(s_)
            return f(ret_t_)(new_s_) 
        return type(self)(composition)

    def run_state(self, with_:S) -> typ.Tuple[T, S]: 
        return self.state(with_)
    

def get(_) -> StateLike[S, S] : 
    return lambda s_: (s_, s_)


def put(s_: S) -> StateLike[S, typ.Any]: 
    return lambda _: (object(), s_)


def modify(f:typ.Callable[[S], S]) -> StateLike[S, typ.Any] : 
    return lambda s_: (object(), f(s_))

def compose(f, g) : 
    def _ (x) : 
        return f(g(x))
    return _ 


class DoWhen: 
    def __init__(self, *conds) :
        self.conds = conds

    def __call__(self, effect:typ.Callable[[T, S], typ.Tuple[U, S]]) : 
        def bindable (payload) : 
            def reducer (state) :
                if all(cond(state) for cond in self.conds) :
                    return effect(payload, state)
                else: 
                    return payload, state
            return reducer
        return bindable