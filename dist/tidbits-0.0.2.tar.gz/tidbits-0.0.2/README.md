# Tidbits

Author: Tang U-Liang 

Email: uliang6482@gmail.com 

Package containing utility functions for use in various projects. 

-----------------

- _added v0.0.1_ Chunker class. Chunker yields list's of set size from a generator function. Useful if we want do a buffered randomization. 

- _added v0.0.2_ State monad preprocessor class and state operation class DoWhen. The preprocessor class contains makes the point free chaining API available to state monads via the `.pipe` method on the class.  
