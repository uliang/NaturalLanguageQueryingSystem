from setuptools import setup


setup(
    name="parsers", 
    entry_points={
        "spacy_factories": ["kb=parsers:SalarySchemeParser", 
                            "type=parsers:QuestionTypeParser"]
    }
)