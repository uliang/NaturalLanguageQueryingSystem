import re
from operator import itemgetter

from spacy.tokens import Doc 


class QuestionTypeParser: 
    def __init__(self, nlp, **cfgs) :
        Doc.set_extension('qtype', default='Unrecognized')

    def __call__(self, doc) : 
        qtype, _ = max(doc.cats.items(), key=itemgetter(1))
        
        doc._.qtype = qtype     
        
        return doc


class SalarySchemeParser:
    def __init__(self, nlp, **cfgs) : 
        Doc.set_extension('kb_ident', default=None)

    def __call__(self, doc) : 
        if doc._.qtype == 'Salary': 
            entity, *_ = doc.ents

            scheme_match = re.search(r'(mss|tss|pas|pxs|ips|ipsh)', entity.text,
                                     flags=re.IGNORECASE)
            level_match = re.search(r'(\d+[Hh]?)', entity.text) 
            matches = [scheme_match, level_match]
            
            if all(matches) : 
                doc._.kb_ident = ' '.join(m.group(0).upper() for m in matches)
            elif scheme_match is None: 
                doc._.kb_ident = ' '.join(['IPS', level_match.group(0)])
                
        return doc

