from setuptools import setup


setup(
    name="parsers", 
    version="0.0.1", 
    entry_points={
        "spacy_factories": ["kb=parsers:SalarySchemeParser", 
                            "type=parsers:QuestionTypeParser"]
    },
    scripts=['parsers.py']
)