from setuptools import setup, find_packages


setup(
    name="parsers", 
    version="0.0.2", 
    entry_points={
        "spacy_factories": ["kb=parsers:SalarySchemeParser", 
                            "type=parsers:QuestionTypeParser"]
    },
    packages = find_packages()
)